#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	
	int num, i;
	
	printf("Digite um numero: ");
	scanf("%d", &num);
	
	for (i=0;i<=num;i++){
       if (i >= num ){
       	printf("%d.\n", i);
	   } else {
	   	printf("%d,\n", i);
	   }
	}
		
	return 0;
}
