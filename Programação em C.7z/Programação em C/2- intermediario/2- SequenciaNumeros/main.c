#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	int cont, num1;
	
	cont = 0;
	
	printf("Digite um n�mero (sem ponto) ");
	scanf("%d", &num1);
	
	for (cont; cont < num1; cont++){
			printf("%d \n", cont);
	}

	
	return 0;
}
