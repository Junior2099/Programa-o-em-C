#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	float nota1,nota2, notaFinal;
	
	printf("Digite a primeira nota ");
	scanf("%f", &nota1);
	
	printf("Digite a segunda nota ");
	scanf("%f", &nota2);
	
	notaFinal = (nota1+nota2) / 2;
	
	if (notaFinal > 6) {
		printf("Aprovado");
	} else {
		printf("Reprovado");
	}
	
	
	return 0;
}
