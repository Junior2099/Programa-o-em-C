#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
  //	set locale  (esqueci)
 	
	int pessoa1, pessoa2, soma;
	
	printf("Digite a idade da primeira pessoa ");
	scanf("%d", &pessoa1);
	
	printf("Digite a idade da segunda pessoa ");
	scanf ("%d", &pessoa2);
	
	soma = pessoa1 + pessoa2;
	 
	printf("A soma das duas idades �: ");
	printf("%d", soma);
	
	
	return 0;
}
