#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	
	setlocale  (LC_ALL,"Portuguese");
	
	float saldo,saque,atual;
	
	
	printf("Digite o seu saldo: (exemplo: 120.0) ");
	scanf("%f", &saldo);
	
		
	printf("Digite o saque que deseja fazer: (exemplo: 20.0) ");
	scanf("%f", &saque);
		
		
	printf("O seu saldo atual � R$: ");	
	atual = (saldo-saque);
	printf("%.2f", atual);
	
	
	
	return 0;
}
