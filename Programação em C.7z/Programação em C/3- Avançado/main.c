#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	setlocale(LC_ALL, "Portuguese");
	
	int ini, final;
	
	printf("Digite o primeiro n�mero\n ");
	scanf ("%d", &ini);
	
	printf("Digite o final dele\n ");
	scanf ("%d", &final);
	
	printf ("O inicio � %d, \n", ini);
	printf ("O final � %d. \n", final);
	
	
	for (ini; ini<final; ini++){
		 if (ini % 2==0){
		 printf("%d, \n", ini);	
		 } 
	}  
		
	return 0;
}
