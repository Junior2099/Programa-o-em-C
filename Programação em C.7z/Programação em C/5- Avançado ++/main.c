#include <stdio.h>
#include <stdlib.h>


void funSomar(numero1, numero2){
	int funSomar = numero1 + numero2;
	printf("A soma entre os numeros e %d", funSomar);
}


void funDividir(numero1,numero2){
	int funDividir = numero1 / numero2;
	printf("A divisao entre os numero e %d", funDividir); 
}

int main(){
	
	int n1,n2;
	
	printf("Digite um numero ");
	scanf ("%d", &n1);
	
	printf("Digite mais um numero ");
	scanf ("%d", &n2);
	
	funSomar(n1,n2);
	
	printf("\n");
	
	funDividir(n1,n2);
	
	return 0;
}
